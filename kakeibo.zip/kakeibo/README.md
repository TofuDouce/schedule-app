# 派對手帳 · 手機記帳網站

單頁應用（SPA），只針對手機版型（最大寬度 480px）。  
視覺主題取自你上傳的金黃派對角色貼圖，沒有沿用參考圖的粉紅白狗。

## 配色（從角色圖抽取）

| 角色 | Hex | 用途 |
| --- | --- | --- |
| 金黃臉 | `#F0C12A` | 主強調、保存按鈕、Today 標籤 |
| 水藍三角旗 | `#2EC8D8` | 收入、心形卡片 |
| 腮紅粉三角旗 | `#F08A9A` | 支出、刪除 |
| 暖紙底 | `#FFF6E8` | 頁面背景 |
| 深褐字 | `#3A2A18` | 正文 |

角色圖位置：

- 右下角 ＋ 按鈕：`assets/mascot-dog.png`
- 頂部裝飾：`assets/mascot-cat.png` / `assets/deco-flags.png`
- 空狀態：`assets/deco-peek.png`、`assets/mascot-cat.png`

## 功能

- 首頁月曆式列表：年月切換、本月結餘、支出／收入心形卡片、每日明細、「沒有支出」、今天標籤
- 新增／編輯彈窗：支出／收入分頁、日期、金額、店家或來源、備註、圖示分類（可新增／刪除）
- 日曆檢視、貯金罐（目標＋進度＋存入）、月度分類報表
- 設定：分類管理、JSON 備份、登出
- Google 登入＋ Firestore 雲端同步；未登入看不到任何記帳資料

## 一、建立 Firebase 專案

1. 開啟 [Firebase Console](https://console.firebase.google.com/) 並登入你的 Google 帳號。
2. 「新增專案」→ 名稱隨意（例如 `party-kakeibo`）→ 關閉 Google Analytics 也可以。
3. 專案建立後進入專案。

### Authentication

1. 左側 **Build → Authentication → 開始使用**
2. **Sign-in method** 分頁 → 開啟 **Google** → 專案支援電子郵件填你的 Gmail → 儲存
3. **Settings** 分頁可把授權網域加上你之後的 Hosting 網域（`localhost` 預設已有）

### Firestore

1. 左側 **Build → Firestore Database → 建立資料庫**
2. 選 **從正式環境模式開始**（規則稍後覆蓋）
3. 地區建議 `asia-east1`（台灣近）
4. 進入 **規則** 分頁，整段貼上本專案的 `firestore.rules`，發布

### 註冊網頁應用、取得設定

1. 專案概覽齒輪旁「新增應用」→ **Web（</>）**
2. 暱稱例如 `kakeibo-web`，可勾選同時設定 Hosting
3. 複製 `firebaseConfig` 物件，貼到 `js/config.js` 的 `window.FIREBASE_CONFIG`

### （選用）只准許自己的 Gmail

在 `js/config.js`：

```js
window.ALLOWED_EMAIL = "you@gmail.com";
```

並可把 `firestore.rules` 裡註解掉的 email 條件打開，改成同一個信箱。

## 二、本機預覽

尚未填入 Firebase 金鑰時，點「使用 Google 登入」會進入 **本地預覽模式**  
（資料存在瀏覽器 `localStorage`，方便先調畫面）。

用任何靜態伺服器打開即可，例如：

```bash
cd kakeibo
python3 -m http.server 8080
```

手機與電腦瀏覽器開 `http://localhost:8080`。  
若要用手機連同一區網，把網址改成電腦的區網 IP。

## 三、部署建議

### 方案 A：Firebase Hosting（推薦，與 Auth 網域一致）

```bash
npm i -g firebase-tools
firebase login
cd kakeibo
firebase use --add          # 選你剛建的專案
firebase deploy
```

`firebase.json` 已寫好 Hosting + Firestore rules。  
部署完成後把該網域加到 Authentication 授權網域。

### 方案 B：GitHub Pages

把整個 `kakeibo` 資料夾推進 GitHub，Pages 來源選 `/` 或 `/docs`。  
記得在 Firebase Authentication 授權網域加上 `你的帳號.github.io`。  
GitHub Pages 是靜態空間，資料仍走 Firebase，沒問題。

## 四、資料結構

```
users/{uid}/entries/{entryId}
  type: "expense" | "income"
  date: "2026-09-14"
  amount: number
  category: string
  store: string
  memo: string
  createdAt: number

users/{uid}/savings/{savingId}
  name, target, current

users/{uid}/settings/categories
  expense: [{ id, name, emoji }]
  income:  [{ id, name, emoji }]
```

安全性規則重點：`request.auth.uid == userId`，使用者彼此完全隔離。

## 五、之後換自己的圖

把 `assets/` 裡四張 PNG 換成同檔名即可：

- `mascot-dog.png`　FAB
- `mascot-cat.png`　頂部／空狀態
- `deco-flags.png`　日曆頂部
- `deco-peek.png`　空月／報表

建議去背 PNG，約 600px 正方形。
