/* =========================================================
 * Firebase 設定
 * 到 Firebase Console → 專案設定 → 你的應用 → SDK 設定
 * 把下面物件整段貼上取代即可。
 * 若 apiKey 仍是 YOUR_ 開頭，App 會進入「本地預覽模式」
 * （資料存在此裝置的 localStorage，方便先看畫面）
 * ========================================================= */

window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

/**
 * 選填：只允許這個 Gmail 使用（其他 Google 帳號登入後會被登出）
 * 留空字串 "" 表示任何成功以 Google 登入的使用者都能用自己的資料。
 */
window.ALLOWED_EMAIL = "";
