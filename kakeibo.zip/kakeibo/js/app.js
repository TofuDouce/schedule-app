(() => {
  "use strict";

  const DEFAULT_CATS = {
    expense: [
      { id: "food", name: "食費", emoji: "🍱" },
      { id: "daily", name: "日用品", emoji: "🧴" },
      { id: "traffic", name: "交通", emoji: "🚃" },
      { id: "fun", name: "娛樂", emoji: "🎮" },
      { id: "beauty", name: "美容", emoji: "💄" },
      { id: "health", name: "醫療", emoji: "💊" },
      { id: "home", name: "居住", emoji: "🏠" },
      { id: "other-e", name: "其他", emoji: "📦" },
    ],
    income: [
      { id: "salary", name: "薪水", emoji: "💰" },
      { id: "pocket", name: "零用錢", emoji: "🎁" },
      { id: "invest", name: "投資", emoji: "📈" },
      { id: "other-i", name: "其他", emoji: "✨" },
    ],
  };

  const PALETTE = ["#f0c12a", "#2ec8d8", "#f08a9a", "#f0a020", "#5cbe7a", "#c4783a", "#8b7cf6", "#59b4d1"];

  const state = {
    view: "login",
    year: 2026,
    month: 9, // 1-12
    selectedDay: null,
    user: null,
    entries: [],
    categories: JSON.parse(JSON.stringify(DEFAULT_CATS)),
    savings: [],
    editing: null,
    ready: false,
  };

  const els = {
    screens: {},
    homeList: document.getElementById("home-list"),
    fab: document.getElementById("fab"),
    tabbar: document.getElementById("tabbar"),
    overlayEntry: document.getElementById("overlay-entry"),
    sheetEntry: document.getElementById("sheet-entry"),
    overlayGen: document.getElementById("overlay-gen"),
    sheetGen: document.getElementById("sheet-gen"),
    toast: document.getElementById("toast"),
    demoBanner: document.getElementById("demo-banner"),
  };
  ["login", "home", "calendar", "savings", "reports", "settings"].forEach((k) => {
    els.screens[k] = document.getElementById("view-" + k);
  });

  const cfg = window.FIREBASE_CONFIG || {};
  const firebaseReady = !!(cfg.apiKey && !String(cfg.apiKey).startsWith("YOUR_"));
  let db = null;
  let auth = null;
  let unsub = [];

  function todayISO() {
    const d = new Date();
    return iso(d.getFullYear(), d.getMonth() + 1, d.getDate());
  }
  function iso(y, m, d) {
    return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  function parseISO(s) {
    const [y, m, d] = s.split("-").map(Number);
    return { y, m, d };
  }
  function monthLabel(y, m) {
    return `${y}.${m}`;
  }
  const WD = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
  function money(n) {
    const v = Math.round(Number(n) || 0);
    const sign = v < 0 ? "-" : "";
    return sign + Math.abs(v).toLocaleString("zh-TW") + "元";
  }
  function moneyOrDash(n, clsEl) {
    const v = Math.round(Number(n) || 0);
    if (!v) {
      if (clsEl) {
        clsEl.classList.add("muted");
        clsEl.classList.remove("inc", "exp");
      }
      return "- 元";
    }
    return money(v);
  }
  function uid() {
    return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  }
  function toast(msg) {
    els.toast.textContent = msg;
    els.toast.style.display = "block";
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (els.toast.style.display = "none"), 1800);
  }

  /* ---------- persistence ---------- */
  const LS_KEY = "party-kakeibo-v1";

  function loadLocal() {
    try {
      const raw = JSON.parse(localStorage.getItem(LS_KEY) || "{}");
      state.entries = raw.entries || demoEntries();
      state.categories = raw.categories || JSON.parse(JSON.stringify(DEFAULT_CATS));
      state.savings = raw.savings || demoSavings();
    } catch {
      state.entries = demoEntries();
      state.savings = demoSavings();
    }
  }
  function saveLocal() {
    localStorage.setItem(
      LS_KEY,
      JSON.stringify({
        entries: state.entries,
        categories: state.categories,
        savings: state.savings,
      })
    );
  }

  function demoEntries() {
    const t = todayISO();
    const { y, m, d } = parseISO(t);
    const yest = iso(y, m, Math.max(1, d - 1));
    return [
      { id: "d1", type: "expense", date: t, amount: 128, category: "food", store: "便利商店", memo: "午餐御飯糰", createdAt: Date.now() },
      { id: "d2", type: "expense", date: t, amount: 75, category: "traffic", store: "悠遊卡", memo: "", createdAt: Date.now() },
      { id: "d3", type: "income", date: yest, amount: 800, category: "pocket", store: "家裡給的", memo: "", createdAt: Date.now() },
    ];
  }
  function demoSavings() {
    return [
      { id: "s1", name: "旅行基金", target: 30000, current: 8600 },
      { id: "s2", name: "緊急備用金", target: 50000, current: 12000 },
    ];
  }

  function col(path) {
    return db.collection("users").doc(state.user.uid).collection(path);
  }

  async function persistEntry(entry, remove) {
    if (!firebaseReady || !state.user) {
      if (remove) state.entries = state.entries.filter((e) => e.id !== entry.id);
      else {
        const i = state.entries.findIndex((e) => e.id === entry.id);
        if (i >= 0) state.entries[i] = entry;
        else state.entries.push(entry);
      }
      saveLocal();
      return;
    }
    const ref = col("entries").doc(entry.id);
    if (remove) await ref.delete();
    else await ref.set({ ...entry, createdAt: entry.createdAt || Date.now() });
  }
  async function persistCats() {
    if (!firebaseReady || !state.user) return saveLocal();
    await db.collection("users").doc(state.user.uid).collection("settings").doc("categories").set(state.categories);
  }
  async function persistSaving(item, remove) {
    if (!firebaseReady || !state.user) {
      if (remove) state.savings = state.savings.filter((s) => s.id !== item.id);
      else {
        const i = state.savings.findIndex((s) => s.id === item.id);
        if (i >= 0) state.savings[i] = item;
        else state.savings.push(item);
      }
      saveLocal();
      return;
    }
    const ref = col("savings").doc(item.id);
    if (remove) await ref.delete();
    else await ref.set(item);
  }

  function listenCloud() {
    unsub.forEach((fn) => fn && fn());
    unsub = [];
    unsub.push(
      col("entries").onSnapshot((snap) => {
        state.entries = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        render();
      })
    );
    unsub.push(
      col("savings").onSnapshot((snap) => {
        state.savings = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (state.view === "savings") renderSavings();
      })
    );
    unsub.push(
      db.collection("users").doc(state.user.uid).collection("settings").doc("categories")
        .onSnapshot((doc) => {
          if (doc.exists) state.categories = doc.data();
        })
    );
  }

  /* ---------- helpers ---------- */
  function monthEntries() {
    const prefix = `${state.year}-${String(state.month).padStart(2, "0")}`;
    return state.entries.filter((e) => String(e.date).startsWith(prefix));
  }
  function catOf(entry) {
    const list = state.categories[entry.type] || [];
    return list.find((c) => c.id === entry.category) || { name: entry.category || "未分類", emoji: "📌" };
  }
  function daysInMonth(y, m) {
    return new Date(y, m, 0).getDate();
  }

  function showView(name) {
    if (!state.user && firebaseReady && name !== "login") name = "login";
    if ((!firebaseReady || state.user) && name === "login") name = "home";
    state.view = name;
    Object.entries(els.screens).forEach(([k, el]) => el.classList.toggle("active", k === name));
    els.tabbar.style.display = name === "login" ? "none" : "grid";
    els.fab.style.display = name === "login" || name === "settings" ? "none" : "block";
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.view === name));
    render();
  }

  /* ---------- render ---------- */
  function render() {
    if (state.view === "login") {
      document.getElementById("login-note").textContent = firebaseReady
        ? "未登入時不會顯示任何記帳資料"
        : "尚未填入 Firebase 設定，點登入可先用本地預覽";
      return;
    }
    document.querySelectorAll(".month-label").forEach((el) => (el.textContent = monthLabel(state.year, state.month)));
    const dim = daysInMonth(state.year, state.month);
    const rangeEl = document.getElementById("month-range");
    if (rangeEl) rangeEl.textContent = `（${state.month}月1日 - ${state.month}月${dim}日）`;
    const badge = document.getElementById("total-badge");
    if (badge) badge.textContent = `${state.month}月收支合計`;
    els.demoBanner.hidden = firebaseReady;
    if (state.view === "home") renderHome();
    if (state.view === "calendar") renderCalendar();
    if (state.view === "savings") renderSavings();
    if (state.view === "reports") renderReports();
    if (state.view === "settings") renderSettings();
  }

  function renderHome() {
    const list = monthEntries();
    const exp = list.filter((e) => e.type === "expense").reduce((s, e) => s + Number(e.amount || 0), 0);
    const inc = list.filter((e) => e.type === "income").reduce((s, e) => s + Number(e.amount || 0), 0);
    const bal = inc - exp;
    document.getElementById("balance-num").innerHTML = `${Math.round(bal).toLocaleString("zh-TW")}<span>元</span>`;
    const expEl = document.getElementById("exp-num");
    const incEl = document.getElementById("inc-num");
    expEl.textContent = moneyOrDash(exp, expEl);
    if (exp) {
      expEl.classList.remove("muted");
      expEl.classList.add("exp");
    }
    incEl.textContent = moneyOrDash(inc, incEl);
    if (inc) {
      incEl.classList.remove("muted");
      incEl.classList.add("inc");
    }

    const dim = daysInMonth(state.year, state.month);
    const now = new Date();
    const isThisMonth = now.getFullYear() === state.year && now.getMonth() + 1 === state.month;
    const todayD = now.getDate();

    const byDay = {};
    list.forEach((e) => {
      const d = Number(String(e.date).slice(8, 10));
      (byDay[d] || (byDay[d] = [])).push(e);
    });

    const days = [];
    for (let d = 1; d <= dim; d++) days.push(d);

    const heartSvg = (color) =>
      `<svg class="mini-heart" viewBox="0 0 32 28"><path fill="${color}" d="M16 26S3.2 17.6.8 11.4C-.6 7.6.6 3.4 4.2 2.1 7.2.9 10.8 2 16 7.2 21.2 2 24.8.9 27.8 2.1c3.6 1.3 4.8 5.5 3.4 9.3C28.8 17.6 16 26 16 26z"/></svg>`;

    els.homeList.innerHTML = days
      .map((d) => {
        const items = byDay[d] || [];
        const dayExp = items.filter((e) => e.type === "expense").reduce((s, e) => s + Number(e.amount), 0);
        const dayInc = items.filter((e) => e.type === "income").reduce((s, e) => s + Number(e.amount), 0);
        const isToday = isThisMonth && d === todayD;
        const wd = WD[new Date(state.year, state.month - 1, d).getDay()];
        const first = items.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))[0];
        const label = first ? first.store || catOf(first).name : "---";
        let right = `<span class="day-right">- - - 元<span class="chev">›</span></span>`;
        let heart = heartSvg("#d8c8b4");
        if (dayInc && !dayExp) {
          right = `<span class="day-right inc">${money(dayInc)}<span class="chev">›</span></span>`;
          heart = heartSvg("#E89AA8");
        } else if (dayExp) {
          const show = dayExp - dayInc;
          right = `<span class="day-right exp">${money(dayExp)}<span class="chev">›</span></span>`;
          heart = heartSvg("#7EBFD0");
        }
        const stamp = dayExp ? "" : `<div class="none-stamp">沒有<br>支出</div>`;
        return `<div class="day-row ${isToday ? "today" : ""}" data-day="${d}">
          ${isToday ? `<span class="today-ribbon">Today</span>` : ""}
          <div class="day-top">
            <div>
              <div class="day-date">${state.month}/${d}</div>
              <div class="day-wd">[${wd}]</div>
            </div>
            <div class="day-mid">${heart}<span class="day-label ${first ? "has" : ""}">${escapeHtml(label)}</span></div>
            ${right}
          </div>
          ${stamp}
        </div>`;
      })
      .join("");
  }

  function entryRow(e) {
    const c = catOf(e);
    const title = e.store || c.name;
    const sub = [c.name, e.memo].filter(Boolean).join(" · ");
    const sign = e.type === "expense" ? "-" : "+";
    return `<div class="entry-line" data-edit="${e.id}">
      <div class="em">${c.emoji}</div>
      <div>
        <div class="ttl">${escapeHtml(title)}</div>
        <div class="sub">${escapeHtml(sub)}</div>
      </div>
      <div class="am ${e.type}">${sign}${money(e.amount)}</div>
    </div>`;
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function renderCalendar() {
    const dows = ["日", "一", "二", "三", "四", "五", "六"];
    document.getElementById("cal-dows").innerHTML = dows
      .map((d, i) => `<div class="cal-dow ${i === 0 ? "sun" : ""}">${d}</div>`)
      .join("");

    const first = new Date(state.year, state.month - 1, 1);
    const startDow = first.getDay();
    const dim = daysInMonth(state.year, state.month);
    const prevDim = daysInMonth(state.year, state.month - 1 || 12);
    const cells = [];
    for (let i = 0; i < startDow; i++) {
      cells.push({ d: prevDim - startDow + 1 + i, out: true });
    }
    for (let d = 1; d <= dim; d++) cells.push({ d, out: false });
    while (cells.length % 7) cells.push({ d: cells.length, out: true, dummy: true });

    const prefix = `${state.year}-${String(state.month).padStart(2, "0")}`;
    const byDay = {};
    state.entries
      .filter((e) => String(e.date).startsWith(prefix))
      .forEach((e) => {
        const d = Number(String(e.date).slice(8, 10));
        if (!byDay[d]) byDay[d] = { exp: 0, inc: 0 };
        byDay[d][e.type === "expense" ? "exp" : "inc"] += Number(e.amount);
      });

    const now = new Date();
    const sel = state.selectedDay || (now.getFullYear() === state.year && now.getMonth() + 1 === state.month ? now.getDate() : 1);

    document.getElementById("cal-grid").innerHTML = cells
      .map((c) => {
        if (c.dummy) return `<div></div>`;
        const sums = !c.out && byDay[c.d];
        const isToday = !c.out && now.getFullYear() === state.year && now.getMonth() + 1 === state.month && now.getDate() === c.d;
        let cap = "";
        if (sums) {
          if (sums.exp) cap = `<div class="c exp">-${Math.round(sums.exp)}</div>`;
          else if (sums.inc) cap = `<div class="c inc">+${Math.round(sums.inc)}</div>`;
        }
        return `<div class="cal-cell ${c.out ? "out" : ""} ${isToday ? "today" : ""}" data-day="${c.out ? "" : c.d}">
          <div class="d">${c.d}</div>${cap}
        </div>`;
      })
      .join("");

    const date = iso(state.year, state.month, sel);
    const items = state.entries.filter((e) => e.date === date).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const box = document.getElementById("cal-day-list");
    box.innerHTML = `<div class="day-block">
      <div class="day-head"><span class="day-date">${state.month}/${sel}</span></div>
      ${items.length ? items.map(entryRow).join("") : `<div class="empty-day"><img src="assets/mascot-cat.png" alt="" />沒有支出</div>`}
    </div>`;
  }

  function renderSavings() {
    const list = document.getElementById("savings-list");
    const cards = (state.savings || [])
      .map((s) => {
        const pct = s.target ? Math.min(100, Math.round((Number(s.current) / Number(s.target)) * 100)) : 0;
        return `<div class="saving-card" data-sid="${s.id}">
          <div class="saving-top">
            <div class="jar">
              <div class="jar-lid"></div>
              <div class="jar-body"><div class="jar-fill" style="height:${pct}%"></div></div>
            </div>
            <div style="flex:1">
              <div class="saving-name">${escapeHtml(s.name)}</div>
              <div class="saving-meta">${money(s.current)} / ${money(s.target)}　${pct}%</div>
            </div>
          </div>
          <div class="bar"><i style="width:${pct}%"></i></div>
          <div class="saving-actions">
            <button class="chip-btn gold" data-save-act="add" data-sid="${s.id}">存一筆</button>
            <button class="chip-btn pink" data-save-act="edit" data-sid="${s.id}">編輯</button>
          </div>
        </div>`;
      })
      .join("");
    list.innerHTML = `
      <button class="add-row" id="add-saving">＋ 新增貯金目標</button>
      ${cards || `<div class="month-empty"><img src="assets/mascot-dog.png" alt="" /><p>還沒有貯金罐，設一個小目標吧</p></div>`}
    `;
  }

  function renderReports() {
    const list = monthEntries();
    const exp = list.filter((e) => e.type === "expense");
    const inc = list.filter((e) => e.type === "income");
    const expSum = exp.reduce((s, e) => s + Number(e.amount), 0);
    const incSum = inc.reduce((s, e) => s + Number(e.amount), 0);

    const byCat = {};
    exp.forEach((e) => {
      const c = catOf(e);
      const key = c.id || c.name;
      if (!byCat[key]) byCat[key] = { name: c.name, emoji: c.emoji, amount: 0 };
      byCat[key].amount += Number(e.amount);
    });
    const rows = Object.values(byCat).sort((a, b) => b.amount - a.amount);
    const max = rows[0]?.amount || 1;

    const donut = drawDonut(rows, expSum);

    document.getElementById("reports-body").innerHTML = `
      <div class="report-card">
        <div style="font-weight:800;margin-bottom:8px">本月概況</div>
        <div style="display:flex;gap:16px;font-weight:800">
          <div>支出 ${money(expSum)}</div>
          <div style="color:var(--cyan-d)">收入 ${money(incSum)}</div>
        </div>
      </div>
      <div class="report-card">
        <div style="font-weight:800;margin-bottom:12px">支出分類</div>
        ${
          rows.length
            ? `<div class="donut-wrap">${donut}
            <div class="legend">${rows
              .map((r, i) => `<div class="legend-row"><span class="dot" style="background:${PALETTE[i % PALETTE.length]}"></span>${r.emoji} ${escapeHtml(r.name)}　${money(r.amount)}</div>`)
              .join("")}</div></div>`
            : `<div class="empty-day"><img src="assets/deco-flags.png" alt="" />這個月還沒有支出</div>`
        }
      </div>
      <div class="report-card">
        <div style="font-weight:800;margin-bottom:8px">分類明細</div>
        ${
          rows
            .map((r, i) => {
              const w = Math.max(6, Math.round((r.amount / max) * 100));
              return `<div class="bar-row"><div class="nm">${r.emoji} ${escapeHtml(r.name)}</div>
                <div class="bar-track"><i style="width:${w}%;background:${PALETTE[i % PALETTE.length]}"></i></div>
                <div class="am">${money(r.amount)}</div></div>`;
            })
            .join("") || `<div style="color:var(--muted);font-size:13px">尚無資料</div>`
        }
      </div>
    `;
  }

  function drawDonut(rows, total) {
    const size = 132, r = 46, cx = 66, cy = 66;
    if (!rows.length || !total) {
      return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#f3e6d0" stroke-width="18"/></svg>`;
    }
    let acc = 0;
    const C = 2 * Math.PI * r;
    const parts = rows.map((row, i) => {
      const frac = row.amount / total;
      const dash = frac * C;
      const gap = C - dash;
      const rot = acc * 360 - 90;
      acc += frac;
      return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${PALETTE[i % PALETTE.length]}" stroke-width="18"
        stroke-dasharray="${dash} ${gap}" transform="rotate(${rot} ${cx} ${cy})" stroke-linecap="butt"/>`;
    });
    return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${parts.join("")}
      <text x="${cx}" y="${cy - 4}" text-anchor="middle" font-size="11" fill="#9a7f63" font-weight="700">支出</text>
      <text x="${cx}" y="${cy + 14}" text-anchor="middle" font-size="13" fill="#3a2a18" font-weight="800">${money(total)}</text>
    </svg>`;
  }

  function renderSettings() {
    const u = state.user;
    const email = u?.email || (firebaseReady ? "" : "本地預覽");
    const name = u?.displayName || "派對手帳";
    const photo = u?.photoURL;
    document.getElementById("settings-body").innerHTML = `
      <div class="set-card">
        <div class="user-box">
          <div class="avatar">${photo ? `<img src="${photo}" alt="">` : "🎉"}</div>
          <div>
            <div style="font-weight:800">${escapeHtml(name)}</div>
            <div style="font-size:12px;color:var(--muted)">${escapeHtml(email)}</div>
          </div>
        </div>
      </div>
      <div class="set-card">
        <button class="set-item" id="manage-exp">🍱 支出分類<span class="r">${state.categories.expense.length} 項 ›</span></button>
        <button class="set-item" id="manage-inc">💰 收入分類<span class="r">${state.categories.income.length} 項 ›</span></button>
      </div>
      <div class="set-card">
        <button class="set-item" id="export-json">⬇️ 匯出備份（JSON）<span class="r">›</span></button>
        ${firebaseReady ? `<button class="set-item" id="btn-logout">🚪 登出</button>` : `<button class="set-item" id="reset-local">🗑️ 清除本地示範資料</button>`}
      </div>
      <p style="color:var(--muted);font-size:12px;padding:4px 8px 24px;line-height:1.6">
        資料存放於 ${firebaseReady ? "你的 Firebase 帳號（僅自己的 uid 可見）" : "此裝置 localStorage"}。<br>
        視覺主題取自你上傳的金黃派對角色：主色 #F0C12A、水藍 #2EC8D8、腮紅粉 #F08A9A。
      </p>
    `;
  }

  /* ---------- sheets ---------- */
  function openEntry(existing) {
    state.editing = existing || null;
    const e = existing || {
      type: "expense",
      date: state.selectedDay ? iso(state.year, state.month, state.selectedDay) : todayISO(),
      amount: "",
      category: "",
      store: "",
      memo: "",
    };
    paintEntrySheet(e);
    els.overlayEntry.classList.add("show");
  }

  function dateDot(s) {
    const p = parseISO(s);
    return `${p.y}.${p.m}.${p.d}`;
  }

  function readDraft() {
    return {
      type: els.sheetEntry.dataset.type || "expense",
      date: els.sheetEntry.dataset.date || todayISO(),
      amount: document.getElementById("f-amount")?.value || "",
      store: document.getElementById("f-store")?.value || "",
      memo: document.getElementById("f-memo")?.value || "",
      category: els.sheetEntry.dataset.cat || "",
    };
  }

  function paintEntrySheet(e) {
    const cats = state.categories[e.type] || [];
    const isExp = e.type === "expense";
    const storePh = isExp ? "藥妝店、超商…" : "薪水、零用錢…";
    const memoPh = isExp ? "食品、日用品…" : "這個月加班變多了…";
    const storeLab = isExp ? "店家" : "種類";
    const amt = e.amount === "" || e.amount == null ? "" : e.amount;
    els.sheetEntry.innerHTML = `
      <div class="sheet-head">
        <div class="nav">
          <button type="button" data-day-shift="-1">‹</button>
          <span id="sheet-date-lab">${dateDot(e.date)}</span>
          <button type="button" data-day-shift="1">›</button>
        </div>
        <button type="button" class="xbtn" id="close-entry">×</button>
      </div>
      <div class="seg">
        <button type="button" class="${isExp ? "on exp" : ""}" data-type="expense">支出</button>
        <button type="button" class="${!isExp ? "on inc" : ""}" data-type="income">收入</button>
      </div>
      <div class="form">
        <div class="row">
          <span class="ico">📅</span><span class="lab">日期</span>
          <span class="val">${dateDot(e.date)}</span>
        </div>
        <div class="row" id="amt-row">
          <span class="ico">💴</span><span class="lab">金額</span>
          <span class="val" style="display:flex;align-items:center;gap:6px">
            <input id="f-amount" inputmode="decimal" value="${escapeHtml(String(amt))}" placeholder="0"
              style="width:96px;border:0;text-align:right;font-weight:800;font-size:18px;outline:none" />
            <span class="amt-zero ${isExp ? "" : "inc"}">${amt === "" || Number(amt) === 0 ? "0" : ""}</span> 元
          </span>
        </div>
        <div class="field-block">
          <div class="lab-row"><span>${isExp ? "💙" : "💗"}</span> ${storeLab}</div>
          <input id="f-store" maxlength="25" placeholder="${storePh}" value="${escapeHtml(e.store || "")}" />
          <div class="counter" id="store-cnt">${(e.store || "").length}/25</div>
        </div>
        <div class="field-block">
          <div class="lab-row">✏️ 備註</div>
          <textarea id="f-memo" maxlength="50" placeholder="${memoPh}">${escapeHtml(e.memo || "")}</textarea>
          <div class="counter" id="memo-cnt">${(e.memo || "").length}/50</div>
        </div>
        <div class="cat-title">📁 分類</div>
        <div class="arch-grid">
          ${cats
            .map(
              (c) => `<button type="button" class="arch ${e.category === c.id ? "on " + e.type : ""}" data-cid="${c.id}">
              <span class="e">${c.emoji}</span><span class="n">${escapeHtml(c.name)}</span></button>`
            )
            .join("")}
          <button type="button" class="arch add" id="add-cat">＋</button>
        </div>
      </div>
      <button class="btn-save ${isExp ? "" : "inc"}" id="save-entry">＋ 保存</button>
      ${state.editing ? `<button class="btn-danger" id="del-entry">刪除這筆</button>` : ""}
    `;
    els.sheetEntry.dataset.type = e.type;
    els.sheetEntry.dataset.cat = e.category || "";
    els.sheetEntry.dataset.date = e.date;
    const store = document.getElementById("f-store");
    const memo = document.getElementById("f-memo");
    store.addEventListener("input", () => (document.getElementById("store-cnt").textContent = `${store.value.length}/25`));
    memo.addEventListener("input", () => (document.getElementById("memo-cnt").textContent = `${memo.value.length}/50`));
  }

  function openDaySheet(d) {
    state.selectedDay = d;
    const date = iso(state.year, state.month, d);
    const items = state.entries.filter((e) => e.date === date).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    openGen(`
      <div class="sheet-head" style="padding-left:8px">
        <div class="nav"><span>${state.month}/${d}</span></div>
        <button type="button" class="xbtn" id="close-gen">×</button>
      </div>
      ${items.length ? items.map(entryRow).join("") : `<div class="month-empty"><img src="assets/mascot-cat.png" alt="" /><p>沒有支出</p></div>`}
      <button class="btn-save" id="add-for-day">＋ 新增這天的紀錄</button>
    `);
  }

  function closeSheets() {
    els.overlayEntry.classList.remove("show");
    els.overlayGen.classList.remove("show");
  }

  function openGen(html) {
    els.sheetGen.innerHTML = `<div class="handle"></div>` + html;
    els.overlayGen.classList.add("show");
  }

  function openSavingForm(item) {
    const s = item || { name: "", target: "", current: 0 };
    openGen(`
      <h3>${item ? "編輯貯金罐" : "新增貯金罐"}</h3>
      <div class="field"><label>名稱</label><input id="sv-name" value="${escapeHtml(s.name)}" placeholder="例如 旅行基金" /></div>
      <div class="field"><label>目標金額</label><input id="sv-target" inputmode="decimal" value="${s.target || ""}" placeholder="30000" /></div>
      <div class="field"><label>目前金額</label><input id="sv-current" inputmode="decimal" value="${s.current || 0}" /></div>
      <button class="btn-save" id="save-saving">${item ? "保存" : "建立"}</button>
      ${item ? `<button class="btn-danger" id="del-saving">刪除這個目標</button>` : ""}
    `);
    els.sheetGen.dataset.sid = item ? item.id : "";
  }

  function openDeposit(item) {
    openGen(`
      <h3>存入「${escapeHtml(item.name)}」</h3>
      <div class="field"><label>金額</label><input class="amt-input" id="sv-dep" inputmode="decimal" placeholder="0" /></div>
      <button class="btn-save" id="do-deposit">存進去</button>
    `);
    els.sheetGen.dataset.sid = item.id;
  }

  function openCats(type) {
    const list = state.categories[type];
    openGen(`
      <h3>${type === "expense" ? "支出分類" : "收入分類"}</h3>
      <div id="cat-admin">
        ${list
          .map(
            (c) => `<div class="set-item" style="border-radius:0">
              <span>${c.emoji} ${escapeHtml(c.name)}</span>
              <button class="r" data-del-cat="${c.id}" data-ctype="${type}" style="border:0;background:transparent;color:var(--pink-d);cursor:pointer">刪除</button>
            </div>`
          )
          .join("")}
      </div>
      <div class="field" style="margin-top:12px"><label>新增分類</label>
        <div style="display:flex;gap:8px">
          <input id="new-emo" placeholder="🍱" style="width:64px;text-align:center" maxlength="3" />
          <input id="new-name" placeholder="名稱" />
        </div>
      </div>
      <button class="btn-save" id="add-cat-save" data-ctype="${type}">新增</button>
    `);
  }

  /* ---------- events ---------- */
  document.getElementById("btn-google").addEventListener("click", async () => {
    if (!firebaseReady) {
      state.user = { uid: "local", email: "local@preview", displayName: "本地預覽" };
      loadLocal();
      showView("home");
      toast("已進入本地預覽");
      return;
    }
    try {
      const provider = new firebase.auth.GoogleAuthProvider();
      await auth.signInWithPopup(provider);
    } catch (err) {
      console.error(err);
      toast("登入失敗：" + (err.code || "請再試一次"));
    }
  });

  document.querySelectorAll("[data-shift]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const n = Number(btn.dataset.shift);
      state.month += n;
      if (state.month < 1) {
        state.month = 12;
        state.year -= 1;
      }
      if (state.month > 12) {
        state.month = 1;
        state.year += 1;
      }
      state.selectedDay = null;
      render();
    });
  });

  els.tabbar.addEventListener("click", (ev) => {
    const tab = ev.target.closest(".tab");
    if (tab) showView(tab.dataset.view);
  });

  els.fab.addEventListener("click", () => openEntry(null));

  document.getElementById("home-list").addEventListener("click", (ev) => {
    const row = ev.target.closest("[data-day]");
    if (row) openDaySheet(Number(row.dataset.day));
  });
  document.getElementById("cal-day-list").addEventListener("click", onEditClick);
  function onEditClick(ev) {
    const card = ev.target.closest("[data-edit]");
    if (!card) return;
    const item = state.entries.find((e) => e.id === card.dataset.edit);
    if (item) openEntry(item);
  }

  document.getElementById("cal-grid").addEventListener("click", (ev) => {
    const cell = ev.target.closest("[data-day]");
    if (!cell || !cell.dataset.day) return;
    state.selectedDay = Number(cell.dataset.day);
    renderCalendar();
  });

  document.getElementById("savings-list").addEventListener("click", (ev) => {
    if (ev.target.id === "add-saving") return openSavingForm(null);
    const btn = ev.target.closest("[data-save-act]");
    if (!btn) return;
    const item = state.savings.find((s) => s.id === btn.dataset.sid);
    if (!item) return;
    if (btn.dataset.saveAct === "add") openDeposit(item);
    else openSavingForm(item);
  });

  document.getElementById("settings-body").addEventListener("click", (ev) => {
    const id = ev.target.closest("button")?.id;
    if (id === "manage-exp") openCats("expense");
    if (id === "manage-inc") openCats("income");
    if (id === "btn-logout") auth.signOut();
    if (id === "reset-local") {
      localStorage.removeItem(LS_KEY);
      loadLocal();
      render();
      toast("已重設示範資料");
    }
    if (id === "export-json") {
      const blob = new Blob([JSON.stringify({ entries: state.entries, categories: state.categories, savings: state.savings }, null, 2)], {
        type: "application/json",
      });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `kakeibo-backup-${todayISO()}.json`;
      a.click();
    }
  });

  els.overlayEntry.addEventListener("click", (ev) => {
    if (ev.target === els.overlayEntry) closeSheets();
  });
  els.overlayGen.addEventListener("click", (ev) => {
    if (ev.target === els.overlayGen) closeSheets();
  });

  els.sheetEntry.addEventListener("click", async (ev) => {
    if (ev.target.id === "close-entry") {
      closeSheets();
      return;
    }
    const shift = ev.target.closest("[data-day-shift]");
    if (shift) {
      const draft = readDraft();
      const p = parseISO(draft.date);
      const dt = new Date(p.y, p.m - 1, p.d + Number(shift.dataset.dayShift));
      draft.date = iso(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
      paintEntrySheet(draft);
      return;
    }
    const typeBtn = ev.target.closest("[data-type]");
    if (typeBtn) {
      const next = readDraft();
      next.type = typeBtn.dataset.type;
      next.category = "";
      paintEntrySheet(next);
      return;
    }
    const cat = ev.target.closest("[data-cid]");
    if (cat) {
      els.sheetEntry.querySelectorAll(".arch").forEach((n) => n.classList.remove("on", "exp", "inc"));
      cat.classList.add("on", els.sheetEntry.dataset.type);
      els.sheetEntry.dataset.cat = cat.dataset.cid;
      return;
    }
    if (ev.target.id === "add-cat" || ev.target.closest("#add-cat")) {
      const type = els.sheetEntry.dataset.type;
      const name = prompt("分類名稱？");
      if (!name) return;
      const emoji = prompt("選一個 emoji", type === "expense" ? "📌" : "✨") || "📌";
      const item = { id: "c-" + uid(), name: name.trim(), emoji };
      state.categories[type].push(item);
      await persistCats();
      const draft = readDraft();
      draft.category = item.id;
      paintEntrySheet(draft);
      return;
    }
    if (ev.target.id === "save-entry") {
      const amount = Number(document.getElementById("f-amount").value);
      if (!amount || amount <= 0) return toast("請輸入金額");
      const type = els.sheetEntry.dataset.type;
      const category = els.sheetEntry.dataset.cat;
      if (!category) return toast("請選一個分類");
      const entry = {
        id: state.editing?.id || uid(),
        type,
        date: els.sheetEntry.dataset.date,
        amount,
        category,
        store: document.getElementById("f-store").value.trim(),
        memo: document.getElementById("f-memo").value.trim(),
        createdAt: state.editing?.createdAt || Date.now(),
      };
      if (firebaseReady && state.user) {
        // keep in local list immediately for snappy UI
        const i = state.entries.findIndex((x) => x.id === entry.id);
        if (i >= 0) state.entries[i] = entry;
        else state.entries.push(entry);
      }
      await persistEntry(entry, false);
      closeSheets();
      const p = parseISO(entry.date);
      state.year = p.y;
      state.month = p.m;
      render();
      toast("已保存");
      return;
    }
    if (ev.target.id === "del-entry" && state.editing) {
      if (!confirm("確定刪除這筆？")) return;
      await persistEntry(state.editing, true);
      if (firebaseReady) state.entries = state.entries.filter((x) => x.id !== state.editing.id);
      closeSheets();
      render();
      toast("已刪除");
    }
  });

  els.sheetGen.addEventListener("click", async (ev) => {
    if (ev.target.id === "close-gen") {
      closeSheets();
      return;
    }
    if (ev.target.id === "add-for-day") {
      closeSheets();
      openEntry(null);
      return;
    }
    const edit = ev.target.closest("[data-edit]");
    if (edit) {
      const item = state.entries.find((e) => e.id === edit.dataset.edit);
      if (item) {
        closeSheets();
        openEntry(item);
      }
      return;
    }
    if (ev.target.id === "save-saving") {
      const name = document.getElementById("sv-name").value.trim();
      const target = Number(document.getElementById("sv-target").value);
      const current = Number(document.getElementById("sv-current").value) || 0;
      if (!name || !target) return toast("請填名稱與目標");
      const item = {
        id: els.sheetGen.dataset.sid || uid(),
        name,
        target,
        current,
      };
      await persistSaving(item, false);
      if (firebaseReady) {
        const i = state.savings.findIndex((s) => s.id === item.id);
        if (i >= 0) state.savings[i] = item;
        else state.savings.push(item);
      }
      closeSheets();
      renderSavings();
      toast("貯金罐已更新");
    }
    if (ev.target.id === "del-saving") {
      const item = state.savings.find((s) => s.id === els.sheetGen.dataset.sid);
      if (!item) return;
      if (!confirm("刪除這個貯金罐？")) return;
      await persistSaving(item, true);
      if (firebaseReady) state.savings = state.savings.filter((s) => s.id !== item.id);
      closeSheets();
      renderSavings();
    }
    if (ev.target.id === "do-deposit") {
      const item = state.savings.find((s) => s.id === els.sheetGen.dataset.sid);
      const n = Number(document.getElementById("sv-dep").value);
      if (!item || !n) return toast("請輸入金額");
      item.current = Number(item.current) + n;
      await persistSaving(item, false);
      closeSheets();
      renderSavings();
      toast("已存入 " + money(n));
    }
    const delc = ev.target.closest("[data-del-cat]");
    if (delc) {
      const type = delc.dataset.ctype;
      state.categories[type] = state.categories[type].filter((c) => c.id !== delc.dataset.delCat);
      await persistCats();
      openCats(type);
    }
    if (ev.target.id === "add-cat-save") {
      const type = ev.target.dataset.ctype;
      const name = document.getElementById("new-name").value.trim();
      const emoji = document.getElementById("new-emo").value.trim() || "📌";
      if (!name) return toast("請輸入名稱");
      state.categories[type].push({ id: "c-" + uid(), name, emoji });
      await persistCats();
      openCats(type);
      toast("已新增分類");
    }
  });

  /* ---------- boot ---------- */
  function initDate() {
    const n = new Date();
    state.year = n.getFullYear();
    state.month = n.getMonth() + 1;
  }

  async function afterLogin(user) {
    const allow = (window.ALLOWED_EMAIL || "").trim();
    if (allow && user.email && user.email.toLowerCase() !== allow.toLowerCase()) {
      toast("這個帳號沒有使用權限");
      await auth.signOut();
      return;
    }
    state.user = user;
    if (firebaseReady) {
      const catRef = db.collection("users").doc(user.uid).collection("settings").doc("categories");
      const snap = await catRef.get();
      if (!snap.exists) await catRef.set(DEFAULT_CATS);
      else state.categories = snap.data();
      listenCloud();
    }
    showView("home");
  }

  function boot() {
    initDate();
    if (!firebaseReady) {
      showView("login");
      return;
    }
    firebase.initializeApp(cfg);
    auth = firebase.auth();
    db = firebase.firestore();
    auth.onAuthStateChanged((user) => {
      if (user) afterLogin(user);
      else {
        state.user = null;
        unsub.forEach((fn) => fn && fn());
        unsub = [];
        state.entries = [];
        state.savings = [];
        showView("login");
      }
    });
  }

  boot();
})();
